<?php

/**
 * @newable
 */
class EtcdConfigParseError extends Exception {
}
